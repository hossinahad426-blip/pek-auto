# PAC RUSH AI (Android, offline)

Build: GitHub Actions (see top-level instructions). Output: app-debug.apk.

Pipeline: MediaProjection frame (360px wide) -> color classification -> ring circle fit
-> player/target/spike blobs -> spike velocity tracking -> collision simulation for KEEP vs REVERSE
-> AccessibilityService tap (dispatchGesture).
