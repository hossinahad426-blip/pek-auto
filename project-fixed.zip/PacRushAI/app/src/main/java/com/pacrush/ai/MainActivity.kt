package com.pacrush.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private val h = Handler(Looper.getMainLooper())
    private lateinit var tvA11y: TextView
    private lateinit var tvCap: TextView
    private lateinit var tvAi: TextView
    private lateinit var tvGame: TextView
    private lateinit var tvInfo: TextView
    private var pendingAi = false

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 300) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(0, dp(3), 0, dp(3))
        return t
    }

    private fun btn(text: String, color: Int, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(color)
        b.setOnClickListener { f() }
        b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF0B0F1A.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(30), dp(18), dp(30))
        sv.addView(col)

        col.addView(label(26f, 0xFF4FF2C8.toInt(), true).apply { text = "PAC RUSH AI" })
        tvA11y = label(16f, Color.WHITE); col.addView(tvA11y)
        tvCap = label(16f, Color.WHITE); col.addView(tvCap)
        tvAi = label(16f, Color.WHITE); col.addView(tvAi)
        tvGame = label(16f, Color.WHITE); col.addView(tvGame)
        tvInfo = label(14f, 0xFFB8C1D9.toInt()); col.addView(tvInfo)

        col.addView(btn("ENABLE ACCESSIBILITY", 0xFF3D5AFE.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("START AI", 0xFF00A86B.toInt()) { startAi() })
        col.addView(btn("STOP AI", 0xFFD32F2F.toInt()) { Bus.capture?.setAi(false) })
        col.addView(btn("STOP SCREEN CAPTURE", 0xFF6D4C41.toInt()) { Bus.capture?.stopAll() })
        col.addView(btn("TEST SCREEN", 0xFF8E24AA.toInt()) {
            startActivity(Intent(this, CalibrateActivity::class.java))
        })
        col.addView(btn("SETTINGS", 0xFF455A64.toInt()) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun startAi() {
        if (Bus.service == null) { toast("Enable Accessibility first (ENABLE ACCESSIBILITY)"); return }
                if (Bus.captureOn) {
            Bus.capture?.setAi(true)
            toast("AI running. Open PAC RUSH and start a game.")
            moveTaskToBack(true)
        } else {
            pendingAi = true
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 77)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                    .putExtra("ai", pendingAi)
                startForegroundService(i)
                toast("AI running. Open PAC RUSH and start a game.")
                moveTaskToBack(true)
            } else {
                toast("Screen capture permission denied")
            }
        }
    }

    private fun refresh() {
        val s = Bus.status
        tvA11y.text = "Accessibility: " + (if (Bus.service != null) "ON" else "OFF")
        tvCap.text = "Screen Capture: " + (if (Bus.captureOn) "ON" else "OFF")
        tvAi.text = "AI: " + (if (Bus.aiOn) "RUNNING" else "STOPPED")
        tvGame.text = "Game: " + s.game
        tvInfo.text = if (Bus.captureOn) {
            "Player: " + (if (s.player) "DETECTED" else "NOT FOUND") + "\n" +
                "Target: " + (if (s.target) "DETECTED" else "NONE") + "\n" +
                "Spikes: " + s.spikes + "\n" +
                "Direction: " + s.direction + "\n" +
                "Decision: " + s.decision + "\n" +
                "Reason: " + s.reason + "\n" +
                "Confidence: " + s.conf + "%\n" +
                "State: " + s.state + "   FPS: " + s.fps
        } else {
            if (cfg.load().calibrated()) "Ready. Open PAC RUSH, then press START AI." else ""
        }
    }
}
