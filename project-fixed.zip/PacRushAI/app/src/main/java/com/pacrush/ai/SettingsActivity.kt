package com.pacrush.ai

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Cfg(this)
        val d = resources.displayMetrics.density
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF0B0F1A.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((18 * d).toInt(), (30 * d).toInt(), (18 * d).toInt(), (30 * d).toInt())
        sv.addView(col)

        val title = TextView(this)
        title.text = "SETTINGS"
        title.textSize = 24f
        title.setTextColor(0xFF4FF2C8.toInt())
        col.addView(title)

        for ((k, label) in Cfg.LABELS) {
            val t = TextView(this)
            t.text = label
            t.setTextColor(0xFFB8C1D9.toInt())
            t.setPadding(0, (12 * d).toInt(), 0, 0)
            val e = EditText(this)
            e.inputType = InputType.TYPE_CLASS_NUMBER
            e.setText(cfg.get(k).toString())
            e.setTextColor(Color.WHITE)
            fields[k] = e
            col.addView(t)
            col.addView(e)
        }

        val save = Button(this)
        save.text = "SAVE"
        save.setOnClickListener {
            for ((k, e) in fields) {
                val v = e.text.toString().toIntOrNull()
                if (v != null) cfg.put(k, v)
            }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
        col.addView(save, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (52 * d).toInt()).apply { topMargin = (18 * d).toInt() })

        val reset = Button(this)
        reset.text = "RESET COLORS"
        reset.setOnClickListener {
            for (k in listOf("ring", "player", "target", "spike")) cfg.put(k, 0)
            Toast.makeText(this, "Colors cleared", Toast.LENGTH_SHORT).show()
        }
        col.addView(reset)
        setContentView(sv)
    }
}
