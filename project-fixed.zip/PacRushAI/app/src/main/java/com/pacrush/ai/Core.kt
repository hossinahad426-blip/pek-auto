package com.pacrush.ai

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/** Immutable parameter snapshot. Colors are 0xFFRRGGBB, 0 = not set. */
class P(
    val ring: Int, val player: Int, val target: Int, val spike: Int,
    val tol: Int, val minArea: Int, val cooldownMs: Int, val windowMs: Int,
    val latencyMs: Int, val tapXPct: Int, val tapYPct: Int, val minConf: Int,
    val safetyPx: Int, val gameOverMs: Int
) {
    fun calibrated() = true
}

class Cfg(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("pacrush_cfg", Context.MODE_PRIVATE)

    fun get(k: String): Int = sp.getInt(k, DEFAULTS[k] ?: 0)
    fun put(k: String, v: Int) { sp.edit().putInt(k, v).apply() }

    fun load(): P = P(
        get("ring"), get("player"), get("target"), get("spike"),
        get("tol"), get("minArea"), get("cooldownMs"), get("windowMs"),
        get("latencyMs"), get("tapXPct"), get("tapYPct"), get("minConf"),
        get("safetyPx"), get("gameOverMs")
    )

    companion object {
        val DEFAULTS: Map<String, Int> = linkedMapOf(
            "tol" to 60, "minArea" to 5, "cooldownMs" to 220, "windowMs" to 700,
            "latencyMs" to 120, "tapXPct" to 50, "tapYPct" to 85, "minConf" to 55,
            "safetyPx" to 3, "gameOverMs" to 1000
        )
        val LABELS: Map<String, String> = linkedMapOf(
            "cooldownMs" to "Tap cooldown (ms)",
            "windowMs" to "Prediction window (ms)",
            "latencyMs" to "Capture + tap latency (ms)",
            "tapXPct" to "Tap position X (% of screen width)",
            "tapYPct" to "Tap position Y (% of screen height)",
            "minConf" to "Minimum confidence to tap (%)",
            "safetyPx" to "Safety margin around player (px)",
            "gameOverMs" to "Idle time before game-over (ms)"
        )
    }
}

class Status(
    val game: String = "NOT DETECTED",
    val player: Boolean = false,
    val target: Boolean = false,
    val spikes: Int = 0,
    val direction: String = "-",
    val decision: String = "-",
    val reason: String = "",
    val conf: Int = 0,
    val state: String = "IDLE",
    val fps: Int = 0
)

class Blob(val cx: Float, val cy: Float, val area: Int, val pts: FloatArray, val spacing: Float, val bw: Int, val bh: Int)
class Ring(val cx: Float, val cy: Float, val r: Float, val q: Float)
class Detection(
    val w: Int, val h: Int, val ring: Ring?, val player: Blob?, val playerQ: Float,
    val targets: List<Blob>, val spikes: List<Blob>, val orbitR: Float
)

object Bus {
    @Volatile var service: AutoTapService? = null
    @Volatile var capture: CaptureService? = null
    @Volatile var aiOn = false
    @Volatile var captureOn = false
    @Volatile var status = Status()
    @Volatile var ignoreFx = 0f
    @Volatile var ignoreFy = 0f
}

object Screen {
    @Suppress("DEPRECATION")
    fun size(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }
}
