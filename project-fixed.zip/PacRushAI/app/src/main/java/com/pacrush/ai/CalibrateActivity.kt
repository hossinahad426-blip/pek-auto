package com.pacrush.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

class PreviewView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
    var det: Detection? = null
    private val pa = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = true }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val b = bmp ?: return
        val sc = minOf(width / b.width.toFloat(), height / b.height.toFloat())
        c.save()
        c.translate((width - b.width * sc) / 2f, (height - b.height * sc) / 2f)
        c.scale(sc, sc)
        c.drawBitmap(b, 0f, 0f, null)
        val d = det
        if (d != null) {
            pa.strokeWidth = 1.2f
            d.ring?.let {
                pa.color = Color.CYAN; c.drawCircle(it.cx, it.cy, it.r, pa)
                pa.color = Color.WHITE; c.drawCircle(it.cx, it.cy, d.orbitR, pa)
            }
            d.player?.let { pa.color = Color.GREEN; c.drawCircle(it.cx, it.cy, sqrt(it.area / 3.14159f) + 3f, pa) }
            pa.color = Color.YELLOW
            for (t in d.targets) c.drawCircle(t.cx, t.cy, 17f, pa)
            pa.color = Color.RED
            for (s in d.spikes) c.drawRect(s.cx - s.bw / 2f, s.cy - s.bh / 2f, s.cx + s.bw / 2f, s.cy + s.bh / 2f, pa)
        }
        c.restore()
    }
}

/** TEST SCREEN: load a screenshot of the game and check ring / player / target detection (spikes need motion, so only live). */
class CalibrateActivity : Activity() {
    private lateinit var view: PreviewView
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0B0F1A.toInt())
        root.setPadding((8 * d).toInt(), (24 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.textSize = 13f
        info.text = "Take a screenshot while PAC RUSH is running (ring visible), then LOAD SCREENSHOT.\nCyan = ring, white = orbit, green = player, yellow = target.\nSpikes are found by motion, so they only show up live."
        root.addView(info)
        view = PreviewView(this)
        root.addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val load = Button(this)
        load.text = "LOAD SCREENSHOT"
        load.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 5) }
        root.addView(load)
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 5 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val raw = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: return
            val tw = minOf(360, raw.width)
            val th = (raw.height * tw / raw.width.toFloat()).toInt()
            val sm = Bitmap.createScaledBitmap(raw, tw, th, true)
            val arr = IntArray(tw * th)
            sm.getPixels(arr, 0, tw, 0, 0, tw, th)
            view.bmp = Bitmap.createBitmap(arr, tw, th, Bitmap.Config.ARGB_8888)
            val det = Detector().detect(arr, tw, th, Cfg(this).load(), 0, 0, 0.033f)
            view.det = det
            view.invalidate()
            info.text = "Ring: " + (if (det.ring != null) "OK r=" + det.ring.r.toInt() else "NOT FOUND") +
                "   Player: " + (if (det.player != null) "OK" else "not visible") +
                "   Targets: " + det.targets.size
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image", Toast.LENGTH_LONG).show()
        }
    }
}
