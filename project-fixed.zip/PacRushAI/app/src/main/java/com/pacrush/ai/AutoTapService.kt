package com.pacrush.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AutoTapService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private var box: LinearLayout? = null
    private var tv: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (Bus.service !== this@AutoTapService) return
            if (Bus.captureOn) {
                showOverlay()
                val s = Bus.status
                tv?.text = "AI " + (if (Bus.aiOn) "ON" else "OFF") + " | " + s.state + "\n" +
                    s.decision + " " + s.conf + "% | spikes " + s.spikes
            } else {
                hideOverlay()
            }
            ui.postDelayed(this, 250)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Bus.service = this
        ui.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        if (Bus.service === this) Bus.service = null
        ui.removeCallbacksAndMessages(null)
        hideOverlay()
        if (Bus.aiOn) Bus.capture?.setAi(false)
    }

    /** Tap at a percentage position of the screen. Any tap reverses the player's direction. */
    fun tapAt(xPct: Int, yPct: Int) {
        val (sw, sh) = Screen.size(this)
        val x = sw * xPct / 100f
        val y = sh * yPct / 100f
        ui.post {
            val path = Path()
            path.moveTo(x, y)
            path.lineTo(x + 1f, y + 1f)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 35))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    private fun showOverlay() {
        if (box != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.setBackgroundColor(0xCC000000.toInt())
        b.setPadding(10, 6, 10, 6)
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.text = "PAC RUSH AI"
        val btn = Button(this)
        btn.text = "STOP"
        btn.textSize = 11f
        btn.setOnClickListener {
            val c = Bus.capture
            if (Bus.aiOn) c?.setAi(false) else c?.stopAll()
        }
        b.addView(t)
        b.addView(btn)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(b, lp) } catch (e: Exception) { return }
        box = b
        tv = t
        b.post {
            val (sw, sh) = Screen.size(this)
            Bus.ignoreFx = b.width / sw.toFloat()
            Bus.ignoreFy = b.height / sh.toFloat()
        }
    }

    private fun hideOverlay() {
        val b = box ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(b)
        } catch (e: Exception) {}
        box = null
        tv = null
        Bus.ignoreFx = 0f
        Bus.ignoreFy = 0f
    }
}
