package com.pacrush.ai

import kotlin.math.*

class Decision(val tap: Boolean, val decision: String, val reason: String, val conf: Int)

/**
 * Decision engine. Priorities: 1) survive 2) avoid spikes 3) collect target if safe 4) no needless taps.
 * Screen angles use atan2(dy, dx) with y pointing down, so a positive angular speed = CLOCKWISE.
 */
class Engine {
    private class Track(var x: Float, var y: Float, var vx: Float, var vy: Float, var seen: Long, var matched: Boolean)
    private class Spk(val b: Blob, val vx: Float, val vy: Float)

    private val PIF = PI.toFloat()
    private val PI2 = (2.0 * PI).toFloat()
    private val NONE = 1000f

    private val tracks = ArrayList<Track>()
    private var lastT = 0L
    private var prevTheta = Float.NaN
    private var omega = 0f
    private var stillSec = 0f
    private var movingFrames = 0
    private var missingSec = 0f
    private var lastTap = -1000000L
    private var lastPl: Blob? = null
    private var lastPlMs = 0L

    var state = "IDLE"
        private set
    var dirText = "-"
        private set

    fun reset() {
        tracks.clear(); lastT = 0L; prevTheta = Float.NaN; omega = 0f
        stillSec = 0f; movingFrames = 0; missingSec = 0f; state = "IDLE"; dirText = "-"; lastPl = null
    }

    private fun wrap(a: Float): Float {
        var x = a
        while (x > PIF) x -= PI2
        while (x < -PIF) x += PI2
        return x
    }

    private fun mod2(a: Float): Float {
        var x = a % PI2
        if (x < 0f) x += PI2
        return x
    }

    fun update(d: Detection, nowMs: Long, p: P, aiOn: Boolean): Decision {
        val dt = if (lastT == 0L) 0.033f else ((nowMs - lastT) / 1000f).coerceIn(0.005f, 0.5f)
        lastT = nowMs
        val ring = d.ring
        var pl = d.player
        var predicted = false
        val lp = lastPl
        if (ring != null && pl == null && lp != null && nowMs - lastPlMs < 250 && !prevTheta.isNaN()) {
            val th = prevTheta + omega * dt
            pl = Blob(ring.cx + d.orbitR * cos(th), ring.cy + d.orbitR * sin(th), lp.area, lp.pts, lp.spacing, lp.bw, lp.bh)
            predicted = true
        }
        if (pl != null && !predicted) { lastPl = pl; lastPlMs = nowMs }
        if (ring == null || pl == null) {
            missingSec += dt
            prevTheta = Float.NaN
            movingFrames = 0
            dirText = "-"
            if (missingSec * 1000f > p.gameOverMs) { state = "GAME OVER / IDLE"; tracks.clear() }
            return Decision(false, "NO TAP", if (ring == null) "RING NOT FOUND" else "PLAYER NOT FOUND", 0)
        }
        missingSec = 0f

        // ---- player angular motion ----
        val theta = atan2(pl.cy - ring.cy, pl.cx - ring.cx)
        if (!predicted && !prevTheta.isNaN()) {
            val inst = wrap(theta - prevTheta) / dt
            if (abs(inst) < 30f) {
                omega = omega * 0.55f + inst * 0.45f
                if (abs(inst) > 0.6f) movingFrames++ else movingFrames = 0
            }
        }
        prevTheta = theta
        if (abs(omega) < 0.35f) stillSec += dt else stillSec = 0f
        dirText = if (abs(omega) < 0.35f) "STILL" else if (omega > 0f) "CLOCKWISE" else "COUNTER-CLOCKWISE"
        if (state == "PLAYING" && stillSec * 1000f > p.gameOverMs) state = "GAME OVER / IDLE"
        if (state != "PLAYING" && movingFrames >= 6 && abs(omega) > 0.8f) { state = "PLAYING"; tracks.clear() }

        // ---- spike tracking (velocity estimation) ----
        for (t in tracks) t.matched = false
        val cur = ArrayList<Spk>()
        val maxD = ring.r * 0.30f
        val maxV = ring.r * 4f
        for (b in d.spikes) {
            var best: Track? = null
            var bd = maxD
            for (t in tracks) {
                if (t.matched) continue
                val dd = hypot(t.x - b.cx, t.y - b.cy)
                if (dd < bd) { bd = dd; best = t }
            }
            if (best != null) {
                best.matched = true
                var vx = (b.cx - best.x) / dt
                var vy = (b.cy - best.y) / dt
                val sp = hypot(vx, vy)
                if (sp > maxV) { vx *= maxV / sp; vy *= maxV / sp }
                best.vx = best.vx * 0.5f + vx * 0.5f
                best.vy = best.vy * 0.5f + vy * 0.5f
                if (hypot(best.vx, best.vy) < 10f) { best.vx = 0f; best.vy = 0f }
                best.x = b.cx; best.y = b.cy; best.seen = nowMs
                cur.add(Spk(b, best.vx, best.vy))
            } else {
                tracks.add(Track(b.cx, b.cy, 0f, 0f, nowMs, true))
                cur.add(Spk(b, 0f, 0f))
            }
        }
        tracks.removeAll { nowMs - it.seen > 350 }

        // ---- confidence ----
        val trackQ = if (movingFrames >= 3) 1f else 0.4f
        val conf = ((ring.q * 0.4f + (if (predicted) 0.5f else d.playerQ) * 0.4f + trackQ * 0.2f) * 100f).toInt().coerceIn(0, 100)

        if (!aiOn) return Decision(false, "WAIT", "AI STOPPED", conf)
        if (state != "PLAYING") return Decision(false, "NO TAP", state, conf)
        if (conf < p.minConf) return Decision(false, "NO TAP", "LOW CONFIDENCE", conf)

        // ---- collision prediction ----
        val pr = max(3f, sqrt(pl.area / PIF) * 0.85f) + p.safetyPx
        val step = 0.02f
        val steps = (p.windowMs / 1000f / step).toInt().coerceIn(5, 80)
        val lat = p.latencyMs / 1000f

        fun firstHit(flip: Boolean): Float {
            for (k in 1..steps) {
                val t = k * step
                val a = if (!flip || t <= lat) theta + omega * t
                else theta + omega * lat - omega * (t - lat)
                val ppx = ring.cx + d.orbitR * cos(a)
                val ppy = ring.cy + d.orbitR * sin(a)
                for (s in cur) {
                    val ox = s.vx * t
                    val oy = s.vy * t
                    val hit = pr + s.b.spacing * 0.6f
                    val hit2 = hit * hit
                    val pts = s.b.pts
                    var i = 0
                    while (i < pts.size) {
                        val dx = pts[i] + ox - ppx
                        val dy = pts[i + 1] + oy - ppy
                        if (dx * dx + dy * dy < hit2) return t
                        i += 2
                    }
                }
            }
            return NONE
        }

        val tKeep = firstHit(false)
        val tRev = firstHit(true)
        var want = false
        var reason = "PATH SAFE"
        if (tKeep < NONE) {
            if (tRev >= NONE || tRev > tKeep + 0.06f) { want = true; reason = "SPIKE COLLISION RISK" }
            else reason = "NO SAFE MOVE"
        } else {
            val w = max(abs(omega), 0.3f)
            var bestT = NONE
            var bestK = NONE
            var bestR = NONE
            for (t in d.targets) {
                val dist = hypot(t.cx - ring.cx, t.cy - ring.cy)
                if (abs(dist - d.orbitR) > ring.r * 0.3f) continue
                val phi = atan2(t.cy - ring.cy, t.cx - ring.cx)
                val fwd = if (omega >= 0f) mod2(phi - theta) else mod2(theta - phi)
                val tk = fwd / w
                val tr = 2f * lat + (PI2 - fwd) / w
                val m = min(tk, tr)
                if (m < bestT) { bestT = m; bestK = tk; bestR = tr }
            }
            if (bestT < NONE) {
                if (bestR + 0.2f < bestK && bestR <= p.windowMs / 1000f && tRev >= NONE) {
                    want = true; reason = "TARGET FASTER"
                } else reason = "TARGET AHEAD"
            }
        }

        if (want) {
            if (nowMs - lastTap < p.cooldownMs) return Decision(false, "WAIT", "COOLDOWN", conf)
            lastTap = nowMs
            omega = -omega
            stillSec = 0f
            return Decision(true, "REVERSE", reason, conf)
        }
        return Decision(false, "KEEP", reason, conf)
    }
}
