package com.pacrush.ai

import kotlin.math.*

/**
 * PAC RUSH specific, color-independent detector (tuned on a real screen recording):
 *  - ring: bright cyan outline (hue 168-197 deg) -> circle fit (center, radius)
 *  - player: warm-colored (yellow/orange) compact blob on the orbit annulus
 *  - target: static ball with a black outline on the orbit annulus (fill color changes every time)
 *  - obstacles: moving blobs of varied shapes and colors, using a slow background model
 */
class Detector {
    private var mov = ByteArray(0)
    private var warm = ByteArray(0)
    private var dark = ByteArray(0)
    private var queue = IntArray(0)
    private var bg = FloatArray(0)
    private var bgInit = false
    private val rx = FloatArray(40000)
    private val ry = FloatArray(40000)
    private var ringSm: Ring? = null
    private var ringMiss = 0
    private var frameNo = 0
    private var orbitR = 0f

    private fun hueDeg(r: Int, g: Int, b: Int): Float {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = (mx - mn).toFloat()
        if (d == 0f) return 0f
        var h = if (mx == r) 60f * ((g - b) / d)
        else if (mx == g) 60f * (2f + (b - r) / d)
        else 60f * (4f + (r - g) / d)
        if (h < 0f) h += 360f
        return h
    }

    fun detect(px: IntArray, w: Int, h: Int, p: P, ignW: Int, ignH: Int, dt: Float): Detection {
        val n = w * h
        if (mov.size != n) {
            mov = ByteArray(n); warm = ByteArray(n); dark = ByteArray(n)
            queue = IntArray(n); bg = FloatArray(n * 3); bgInit = false
            ringSm = null; orbitR = 0f
        }
        frameNo++

        // ---------- background model -> moving mask ----------
        java.util.Arrays.fill(mov, 0.toByte())
        if (!bgInit) {
            for (i in 0 until n) {
                val c = px[i]; val k = i * 3
                bg[k] = ((c shr 16) and 255).toFloat(); bg[k + 1] = ((c shr 8) and 255).toFloat(); bg[k + 2] = (c and 255).toFloat()
            }
            bgInit = true
        } else {
            val alpha = (1f - exp(-dt / 2.8f)).coerceIn(0.008f, 0.08f)
            var cnt = 0
            for (i in 0 until n) {
                val c = px[i]; val k = i * 3
                val r = ((c shr 16) and 255).toFloat(); val g = ((c shr 8) and 255).toFloat(); val b = (c and 255).toFloat()
                val d = abs(r - bg[k]) + abs(g - bg[k + 1]) + abs(b - bg[k + 2])
                // Lower threshold catches objects whose colors shift between frames.
                // Freeze background adaptation on moving pixels so slow/gradual color
                // changes do not get absorbed into the background immediately.
                if (d > 58f) {
                    mov[i] = 1
                    cnt++
                } else {
                    bg[k] += (r - bg[k]) * alpha
                    bg[k + 1] += (g - bg[k + 1]) * alpha
                    bg[k + 2] += (b - bg[k + 2]) * alpha
                }
            }
            if (cnt > n * 3 / 5) { // major scene change: reset model
                bgInit = false
                java.util.Arrays.fill(mov, 0.toByte())
            }
        }
        for (y in 0 until min(ignH, h)) for (x in 0 until min(ignW, w)) mov[y * w + x] = 0

        // ---------- ring ----------
        val refresh = (ringSm == null && frameNo % 4 == 0) || frameNo % 30 == 0
        if (refresh) {
            var rn = 0
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    if (x < ignW && y < ignH) continue
                    val c = px[row + x]
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    val mx = max(g, b)
                    if (r < 200 && mx >= 235) {
                        val mn = min(r, min(g, b))
                        if ((mx - mn) * 255 > 110 * mx) {
                            val hd = hueDeg(r, g, b)
                            if (hd >= 168f && hd <= 197f && rn < rx.size) {
                                rx[rn] = x.toFloat(); ry[rn] = y.toFloat(); rn++
                            }
                        }
                    }
                }
            }
            val fit = fitRing(rn, w, h)
            val prev = ringSm
            if (fit != null) {
                ringSm = if (prev != null && abs(prev.cx - fit.cx) < 6f && abs(prev.cy - fit.cy) < 6f && abs(prev.r - fit.r) < 6f)
                    Ring(prev.cx * 0.7f + fit.cx * 0.3f, prev.cy * 0.7f + fit.cy * 0.3f, prev.r * 0.7f + fit.r * 0.3f, fit.q)
                else fit
                ringMiss = 0
            } else if (prev != null) {
                ringMiss++
                if (ringMiss >= 5) ringSm = null
            }
        }
        val ring = ringSm
        if (ring == null) return Detection(w, h, null, null, 0f, emptyList(), emptyList(), 0f)

        val R = ring.r
        val cx = ring.cx
        val cy = ring.cy

        // ---------- warm (player) and dark (target outline) masks in the annulus ----------
        java.util.Arrays.fill(warm, 0.toByte())
        java.util.Arrays.fill(dark, 0.toByte())
        val x0 = max(0, (cx - R * 1.05f).toInt()); val x1 = min(w - 1, (cx + R * 1.05f).toInt())
        val y0 = max(0, (cy - R * 1.05f).toInt()); val y1 = min(h - 1, (cy + R * 1.05f).toInt())
        val lo2 = (0.55f * R) * (0.55f * R); val hi2 = (1.02f * R) * (1.02f * R)
        val dlo2 = (0.68f * R) * (0.68f * R); val dhi2 = (0.98f * R) * (0.98f * R)
        for (y in y0..y1) {
            val dy = y - cy
            for (x in x0..x1) {
                if (x < ignW && y < ignH) continue
                val dx = x - cx
                val d2 = dx * dx + dy * dy
                if (d2 > hi2 || d2 < lo2) continue
                val c = px[y * w + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                if (mx < 70) {
                    if (d2 >= dlo2 && d2 <= dhi2) dark[y * w + x] = 1
                } else if (mx >= 170 && (mx - mn) * 255 >= 150 * mx) {
                    if (hueDeg(r, g, b) <= 80f) warm[y * w + x] = 1
                }
            }
        }

        // ---------- targets ----------
        val darkBlobs = ArrayList<Blob>()
        extract(dark, w, h, max(8, (0.006f * R * R).toInt()), darkBlobs)
        val targets = ArrayList<Blob>()
        for (b in darkBlobs) {
            if (b.bw >= 0.18f * R && b.bw <= 0.5f * R && b.bh >= 0.18f * R && b.bh <= 0.5f * R &&
                abs(b.bw - b.bh) <= 0.12f * R
            ) targets.add(b)
        }

        // ---------- player ----------
        val warmBlobs = ArrayList<Blob>()
        extract(warm, w, h, max(20, (0.012f * R * R).toInt()), warmBlobs)
        val refOrbit = if (orbitR > 0f) orbitR else 0.83f * R
        var player: Blob? = null
        for (b in warmBlobs) {
            if (b.bw < 0.2f * R || b.bw > 0.5f * R || b.bh < 0.2f * R || b.bh > 0.5f * R) continue
            if (max(b.bw, b.bh).toFloat() / min(b.bw, b.bh) > 1.7f) continue
            val d = hypot(b.cx - cx, b.cy - cy)
            if (abs(d - refOrbit) > 0.2f * R) continue
            var nearTarget = false
            for (t in targets) if (hypot(t.cx - b.cx, t.cy - b.cy) < 0.3f * R) nearTarget = true
            if (nearTarget) continue
            if (player == null || b.area > player.area) player = b
        }
        var pq = 0f
        if (player != null) {
            val d = hypot(player.cx - cx, player.cy - cy)
            val off = abs(d - refOrbit) / R
            if (off < 0.1f) orbitR = if (orbitR > 0f) orbitR * 0.95f + d * 0.05f else d
            val areaQ = min(1f, player.area / (0.04f * R * R))
            val offQ = 1f - min(1f, off / 0.15f)
            pq = areaQ * 0.4f + offQ * 0.6f
        }

        // ---------- moving obstacles (color-independent, varied shapes) ----------
        // The game changes obstacle colors, so classify temporal motion rather than hue.
        // Accept compact, vertical, horizontal and irregular objects; reject tiny effects.
        val movBlobs = ArrayList<Blob>()
        extract(mov, w, h, max(18, (0.008f * R * R).toInt()), movBlobs)
        val spikes = ArrayList<Blob>()
        for (b in movBlobs) {
            val shortSide = min(b.bw, b.bh).toFloat()
            val longSide = max(b.bw, b.bh).toFloat()
            val aspect = longSide / max(1f, shortSide)
            val inGameArea = b.cx >= cx - 1.18f * R && b.cx <= cx + 1.18f * R &&
                b.cy >= cy - 1.18f * R && b.cy <= cy + 1.18f * R
            if (inGameArea && b.bw >= 0.08f * R && b.bh >= 0.08f * R &&
                b.bw <= 1.05f * R && b.bh <= 1.05f * R && aspect <= 5.0f
            ) {
                // Do not treat the detected player or collectible as an obstacle.
                val nearPlayer = player != null && hypot(b.cx - player.cx, b.cy - player.cy) < 0.18f * R
                val nearTarget = targets.any { hypot(b.cx - it.cx, b.cy - it.cy) < 0.16f * R }
                if (!nearPlayer && !nearTarget) spikes.add(b)
            }
        }
        spikes.sortByDescending { it.area }
        while (spikes.size > 12) spikes.removeAt(spikes.size - 1)
        return Detection(w, h, ring, player, pq, targets, spikes, if (orbitR > 0f) orbitR else 0.83f * R)
    }

    /** Connected components (8-neighborhood) of mask==1. Clears the mask while scanning. */
    private fun extract(mask: ByteArray, w: Int, h: Int, minArea: Int, out: MutableList<Blob>) {
        val n = w * h
        for (i in 0 until n) {
            if (mask[i].toInt() != 1) continue
            var head = 0
            var tail = 0
            queue[tail++] = i
            mask[i] = 0
            var sx = 0L; var sy = 0L
            var minx = w; var maxx = 0; var miny = h; var maxy = 0
            while (head < tail) {
                val v = queue[head++]
                val vx = v % w
                val vy = v / w
                sx += vx; sy += vy
                if (vx < minx) minx = vx
                if (vx > maxx) maxx = vx
                if (vy < miny) miny = vy
                if (vy > maxy) maxy = vy
                for (dy in -1..1) {
                    val yy = vy + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val xx = vx + dx
                        if (xx < 0 || xx >= w) continue
                        val nb = yy * w + xx
                        if (mask[nb].toInt() == 1) { mask[nb] = 0; queue[tail++] = nb }
                    }
                }
            }
            val area = tail
            if (area < minArea) continue
            val cnt = min(area, 24)
            val step = max(1, area / cnt)
            val pts = FloatArray(cnt * 2)
            for (k in 0 until cnt) {
                val v = queue[min(area - 1, k * step)]
                pts[k * 2] = (v % w).toFloat()
                pts[k * 2 + 1] = (v / w).toFloat()
            }
            out.add(Blob(sx.toFloat() / area, sy.toFloat() / area, area, pts, sqrt(area.toFloat() / cnt), maxx - minx + 1, maxy - miny + 1))
        }
    }

    private fun fitRing(m: Int, w: Int, h: Int): Ring? {
        if (m < 40) return null
        val keep = BooleanArray(m) { true }
        var cx = 0.0
        var cy = 0.0
        var r = 0.0
        var cnt = m
        for (iter in 0 until 4) {
            var sx = 0.0
            var sy = 0.0
            var c = 0
            for (i in 0 until m) if (keep[i]) { sx += rx[i]; sy += ry[i]; c++ }
            if (c < 30) return null
            val mx = sx / c
            val my = sy / c
            var suu = 0.0; var svv = 0.0; var suv = 0.0
            var suuu = 0.0; var svvv = 0.0; var suvv = 0.0; var svuu = 0.0
            for (i in 0 until m) if (keep[i]) {
                val u = rx[i] - mx
                val v = ry[i] - my
                suu += u * u; svv += v * v; suv += u * v
                suuu += u * u * u; svvv += v * v * v
                suvv += u * v * v; svuu += v * u * u
            }
            val det = suu * svv - suv * suv
            if (abs(det) < 1e-6) return null
            val uc = (svv * (suuu + suvv) - suv * (svvv + svuu)) / (2.0 * det)
            val vc = (suu * (svvv + svuu) - suv * (suuu + suvv)) / (2.0 * det)
            r = sqrt(uc * uc + vc * vc + (suu + svv) / c)
            cx = uc + mx
            cy = vc + my
            val thr = max(2.5, r * 0.04) * (if (iter == 0) 3.0 else 1.0)
            cnt = 0
            for (i in 0 until m) {
                val d = hypot(rx[i] - cx, ry[i] - cy)
                keep[i] = abs(d - r) <= thr
                if (keep[i]) cnt++
            }
        }
        if (cnt < 30) return null
        val bins = BooleanArray(24)
        for (i in 0 until m) if (keep[i]) {
            val a = atan2(ry[i] - cy, rx[i] - cx)
            var bi = ((a + PI) / (2 * PI) * 24).toInt()
            if (bi > 23) bi = 23
            if (bi < 0) bi = 0
            bins[bi] = true
        }
        val cov = bins.count { it } / 24.0
        val q = (cnt.toDouble() / m) * min(1.0, cov / 0.6)
        if (q < 0.15 || r < 20.0 || r > 0.8 * max(w, h)) return null
        return Ring(cx.toFloat(), cy.toFloat(), r.toFloat(), q.toFloat().coerceIn(0f, 1f))
    }
}
