package com.pacrush.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import kotlin.math.min

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "pacrush.start"
        const val ACTION_STOP = "pacrush.stop"
        private const val CH = "pacrush_capture"
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var stopped = false
    private var started = false

    private lateinit var cfg: Cfg
    private val detector = Detector()
    private val engine = Engine()
    private var pixels = IntArray(0)
    private var rowBuf = ByteArray(0)
    private var params: P? = null
    private var paramsAt = 0L
    private var lastProc = 0L
    private var prevFrameAt = 0L
    @Volatile private var needReset = false
    private var blackCount = 0
    private var fpsCount = 0
    private var fpsAt = 0L
    private var fps = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cfg = Cfg(this)
        Bus.capture = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun start(intent: Intent) {
        if (started) return
        started = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "PAC RUSH AI", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("PAC RUSH AI")
            .setContentText("Screen capture running")
            .addAction(Notification.Action.Builder(null, "STOP", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        val code = intent.getIntExtra("code", 0)
        val data: Intent? = intent.getParcelableExtra("data")
        if (data == null) { stopAll(); return }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = try { mpm.getMediaProjection(code, data) } catch (e: Exception) { null }
        if (proj == null) { stopAll(); return }
        projection = proj

        val th = HandlerThread("pacrush-vision")
        th.start()
        thread = th
        val hd = Handler(th.looper)
        handler = hd
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { hd.post { stopAll() } }
        }, hd)

        val (sw, sh) = Screen.size(this)
        val w = min(360, sw)
        val h = (sh * (w / sw.toFloat())).toInt()
        val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = rd
        vd = proj.createVirtualDisplay(
            "pacrush", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, hd
        )
        rd.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try { onFrame(img) } catch (e: Exception) { Log.e("PACRUSH", "Frame processing failed", e) } finally { img.close() }
            }
        }, hd)

        Bus.captureOn = true
        Bus.aiOn = intent.getBooleanExtra("ai", false)
        needReset = true
    }

    fun setAi(on: Boolean) {
        if (on) needReset = true
        Bus.aiOn = on
    }

    private fun onFrame(img: Image) {
        val now = SystemClock.elapsedRealtime()
        val minGap = if (Bus.aiOn) 25 else 120
        if (now - lastProc < minGap) return
        lastProc = now

        val w = img.width
        val h = img.height
        if (pixels.size != w * h) pixels = IntArray(w * h)
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        if (rowBuf.size < rs) rowBuf = ByteArray(rs)
        for (y in 0 until h) {
            val start = y * rs
            if (start >= buf.limit()) break
            buf.position(start)
            val len = min(rs, buf.limit() - start)
            buf.get(rowBuf, 0, len)
            var o = 0
            val base = y * w
            for (x in 0 until w) {
                if (o + 2 >= len) break
                pixels[base + x] = -0x1000000 or
                    ((rowBuf[o].toInt() and 255) shl 16) or
                    ((rowBuf[o + 1].toInt() and 255) shl 8) or
                    (rowBuf[o + 2].toInt() and 255)
                o += ps
            }
        }

        // black-frame check (apps with FLAG_SECURE give black frames)
        var dark = true
        var s = 0
        while (s < pixels.size) {
            val c = pixels[s]
            if (((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255) > 30) { dark = false; break }
            s += 97
        }
        blackCount = if (dark) blackCount + 1 else 0

        if (params == null || now - paramsAt > 400) { params = cfg.load(); paramsAt = now }
        val p = params!!

        if (needReset) { engine.reset(); needReset = false }
        if (Bus.aiOn && Bus.service == null) Bus.aiOn = false

        val ignW = if (Bus.ignoreFx > 0f) (Bus.ignoreFx * w * 1.1f).toInt() + 2 else 0
        val ignH = if (Bus.ignoreFy > 0f) (Bus.ignoreFy * h * 1.1f).toInt() + 2 else 0
        val dtSec = if (prevFrameAt == 0L) 0.033f else ((now - prevFrameAt) / 1000f).coerceIn(0.005f, 0.5f)
        prevFrameAt = now
        val det = detector.detect(pixels, w, h, p, ignW, ignH, dtSec)
        val dec = engine.update(det, now, p, Bus.aiOn)
        if (dec.tap && Bus.aiOn) Bus.service?.tapAt(p.tapXPct, p.tapYPct)

        fpsCount++
        if (now - fpsAt >= 1000) { fps = fpsCount; fpsCount = 0; fpsAt = now }
        val game = when {
            blackCount > 15 -> "BLOCKED (BLACK FRAME)"
            det.ring != null && det.player != null -> "DETECTED"
            else -> "NOT DETECTED"
        }
        Bus.status = Status(
            game, det.player != null, det.targets.isNotEmpty(), det.spikes.size,
            engine.dirText, dec.decision, dec.reason, dec.conf, engine.state, fps
        )
    }

    fun stopAll() {
        if (stopped) return
        stopped = true
        Bus.aiOn = false
        Bus.captureOn = false
        Bus.status = Status()
        try { reader?.setOnImageAvailableListener(null, null) } catch (e: Exception) {}
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        thread?.quitSafely()
        if (Bus.capture === this) Bus.capture = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
